package com.example.term2testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //delcare views of the email
        int quantity = 1;
        int quantity2= 1;
         String name;
       Button submitOrder;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button submitOrder = findViewById(R.id.submit_Order);
        submitOrder.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                submitOrder();
            }

        });
    }

    // this method is called when the decrement button is clicked for the Donuts
    public void decrementquantityD(View view){
        quantity = quantity - 1;
       displayquantity(quantity);

    }
    public void incrementquantityD(View view){
        quantity = quantity + 1;
        displayquantity(quantity);
    }

    private void displayquantity(int numberOfDonuts) {
        TextView quantity1 = (TextView) findViewById(R.id.quantitychange_value);
        quantity1.setText("" + numberOfDonuts);
    }

    //this method is called when the decrement button is cliked for the Fro Yo Yogut
    public void decrementquantityFro(View view){
        quantity2 = quantity2 - 1;
        displayquantity2(quantity2);
    }

    public void incrementquantityFro(View view){
        quantity2 = quantity2 + 1;
        displayquantity2(quantity2);
    }

    private void  displayquantity2(int numberOfFroYos){
        TextView quantity1 = (TextView) findViewById(R.id.quantitychange_value2);
        quantity1.setText("" + numberOfFroYos);
    }

    // this method execut then the submit Order button is clicked
    public  void submitOrder(){

        EditText nameText = (EditText) findViewById(R.id.name_Text);
        String names = nameText.getText().toString();

        // Calculate the price
        int price = calculatePrice();

        // Display the order summary on the screen
        String message = createOrderSummary(name,price);
        displayMessage(message);



        //Send the order summery in the eamil body
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto"));
        intent.putExtra(Intent.EXTRA_SUBJECT, "Just Mpumelelo Orders");
        intent.putExtra(Intent.EXTRA_TEXT, message);

        if (intent.resolveActivity(getPackageManager()) != null) {

            startActivity(intent);
        }

    }


    // @return total price
    private int calculatePrice() {
        int price = 10;
        return quantity * price;
    }

    private String createOrderSummary(String name, int price) {
        String priceMessage = "Name : Mpumelelo" + name;
        priceMessage += "\n quantityText1" + quantity;
       // priceMessage += "\n quantityText2" + quantityText2;
        priceMessage += "\n Total: R " + price;
        priceMessage += "\n Thank You";

        return priceMessage;

    }
        // This method displays the given text on the screen.
    private void displayMessage(String message) {
        TextView orderSummaryTextView = (TextView) findViewById(R.id.name_Text);
        orderSummaryTextView.setText(message);
    }

}